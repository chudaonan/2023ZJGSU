package com.example.worktest

data class zxkContact(
    val id: Int,
    val name: String,
    val phone: String,
    val email: String,
    val address: String,
    val relation: String
)
