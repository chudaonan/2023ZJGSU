package com.example.worktest

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class zxkViewActivity : AppCompatActivity() {

    private lateinit var dbHelper: zxkDBHelper //数据库帮助类对象
    private var contactId: Int = 0 //联系人的id

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.zxkactivity_view)

        dbHelper = zxkDBHelper(this) //初始化数据库帮助类对象

        //获取从上一个界面传递过来的联系人的id，并根据id查询到对应的联系人对象
        contactId = intent.getIntExtra("contactId", 0)
        val contact = dbHelper.queryContactById(contactId)

        //如果查询到了联系人对象，就将其信息显示在文本框中
        if (contact != null) {
            findViewById<TextView>(R.id.tv_name).text = "姓名：${contact.name}"
            findViewById<TextView>(R.id.tv_phone).text = "电话：${contact.phone}"
            findViewById<TextView>(R.id.tv_email).text = "邮箱：${contact.email}"
            findViewById<TextView>(R.id.tv_address).text = "地址：${contact.address}"
            findViewById<TextView>(R.id.tv_relation).text = "关系：${contact.relation}"
        }

        findViewById<FloatingActionButton>(R.id.btn_back).setOnClickListener {
            finish()
        }

        findViewById<FloatingActionButton>(R.id.btn_edit).setOnClickListener {
            //点击编辑联系人按钮时，跳转到修改联系人界面，并传递联系人的id
            val intent = Intent(this, zxkEditActivity::class.java)
            intent.putExtra("contactId", contactId)
            startActivity(intent)
            finish()
        }

        findViewById<FloatingActionButton>(R.id.btn_call).setOnClickListener{
            //获取联系人的电话号码
            val phone = contact?.phone
            //创建一个隐式意图，设置动作为ACTION_DIAL，并传递电话号码
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            //启动意图，打开拨号界面
            startActivity(intent)
        }

        findViewById<FloatingActionButton>(R.id.btn_message).setOnClickListener{
            //获取联系人的电话号码和姓名
            val phone = contact?.phone
//            val name = contact?.name
            //创建一个隐式意图，设置动作为ACTION_SENDTO，并传递电话号码
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone"))
//            intent.putExtra("a", "Hello, $name!")
            //启动意图，打开短信界面
            startActivity(intent)
        }
    }
}
