package com.example.worktest

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton

class zxkEditActivity : AppCompatActivity() {

    private lateinit var dbHelper: zxkDBHelper //数据库帮助类对象
    private var contactId: Int = 0 //联系人的id

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.zxkactivity_edit)

        dbHelper = zxkDBHelper(this) //初始化数据库帮助类对象

        //获取从上一个界面传递过来的联系人的id，并根据id查询到对应的联系人对象
        contactId = intent.getIntExtra("contactId", 0)
        val contact = dbHelper.queryContactById(contactId)

        //如果查询到了联系人对象，就将其信息显示在输入框中
        if (contact != null) {
            findViewById<TextView>(R.id.et_name).setText(contact.name)
            findViewById<TextView>(R.id.et_phone).setText(contact.phone)
            findViewById<TextView>(R.id.et_email).setText(contact.email)
            findViewById<TextView>(R.id.et_address).setText(contact.address)
            findViewById<TextView>(R.id.et_relation).setText(contact.relation)
        }

        findViewById<FloatingActionButton>(R.id.btn_exit_edit).setOnClickListener {
            finish()
        }

        findViewById<FloatingActionButton>(R.id.btn_update).setOnClickListener {
            //创建一个AlertDialog.Builder对象
            val builder = AlertDialog.Builder(this)
            //设置对话框的标题和内容
            builder.setTitle("更新联系人")
            builder.setMessage("确定要更新联系人吗？")
            //设置对话框的正面按钮，点击时执行更新操作
            builder.setPositiveButton("确定") { dialog, which ->
                //获取输入框中的内容，并封装成一个Contact对象
                val name = findViewById<TextView>(R.id.et_name).text.toString().trim()
                val phone = findViewById<TextView>(R.id.et_phone).text.toString().trim()
                val email = findViewById<TextView>(R.id.et_email).text.toString().trim()
                val address = findViewById<TextView>(R.id.et_address).text.toString().trim()
                val relation = findViewById<TextView>(R.id.et_relation).text.toString().trim()
                val contact = zxkContact(contactId, name, phone, email, address, relation)

                //判断输入框中的内容是否为空，如果不为空，就调用数据库帮助类的updateContact方法，将联系人对象更新到数据库中
                if (name.isNotEmpty() && phone.isNotEmpty() && email.isNotEmpty() && address.isNotEmpty() && relation.isNotEmpty()) {
                    dbHelper.updateContact(contact)
                    Toast.makeText(this,"更新成功",Toast.LENGTH_SHORT).show()
                    finish() //返回主界面
                } else {
                    Toast.makeText(this,"请填写完整信息",Toast.LENGTH_SHORT).show()
                }
            }
            //设置对话框的反面按钮，点击时取消对话框
            builder.setNegativeButton("取消") { dialog, which ->
                dialog.dismiss() //关闭对话框
            }
            //显示对话框
            builder.show()
        }

        findViewById<FloatingActionButton>(R.id.btn_delete).setOnClickListener {
            //创建一个AlertDialog.Builder对象
            val builder = AlertDialog.Builder(this)
            //设置对话框的标题和内容
            builder.setTitle("删除联系人")
            builder.setMessage("确定要删除联系人吗？")
            //设置对话框的正面按钮，点击时执行删除操作
            builder.setPositiveButton("确定") { dialog, which ->
                //调用数据库帮助类的deleteContact方法，根据联系人的id删除对应的记录
                dbHelper.deleteContact(contactId)
                Toast.makeText(this,"删除成功",Toast.LENGTH_SHORT).show()
                finish() //返回主界面
            }
            //设置对话框的反面按钮，点击时取消对话框
            builder.setNegativeButton("取消") { dialog, which ->
                dialog.dismiss() //关闭对话框
            }
            //显示对话框
            builder.show()
        }
    }
}
