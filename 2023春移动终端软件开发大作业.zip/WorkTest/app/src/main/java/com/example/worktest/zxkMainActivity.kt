package com.example.worktest

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import androidx.appcompat.widget.SearchView //导入SearchView类

class zxkMainActivity : AppCompatActivity(), SearchView.OnQueryTextListener { //实现OnQueryTextListener接口

    private lateinit var dbHelper: zxkDBHelper //数据库帮助类对象
    private lateinit var adapter: zxkContactAdapter //适配器对象
    private lateinit var searchView: SearchView //搜索栏对象

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.zxkactivity_main)

        dbHelper = zxkDBHelper(this) //初始化数据库帮助类对象
        adapter = zxkContactAdapter(this, dbHelper.queryAllContacts()) //初始化适配器对象，并传入查询到的所有联系人列表
        val recycler_view=findViewById<RecyclerView>(R.id.recycler_view)
        recycler_view.layoutManager = LinearLayoutManager(this) //设置recyclerView的布局管理器为线性布局管理器
        recycler_view.adapter = adapter //设置recyclerView的适配器为自定义的适配器对象

        findViewById<FloatingActionButton>(R.id.fab_add).setOnClickListener {
            //点击添加联系人按钮时，跳转到添加联系人界面
            val intent= Intent(this,zxkAddActivity::class.java)
            startActivity(intent)
        }

        searchView = findViewById(R.id.search_view) //获取搜索栏对象
        searchView.setOnQueryTextListener(this) //设置搜索栏的文本监听器为当前活动对象
    }

    override fun onResume() {
        super.onResume()
        //每次返回主界面时，刷新recyclerView的数据源，并通知适配器更新界面
        adapter.dataList = dbHelper.queryAllContacts()
        adapter.notifyDataSetChanged()
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        //当用户提交搜索文本时，调用数据库帮助类的查询方法，根据姓名查找联系人，如果找到了，就跳转到查看联系人界面，并传递联系人的id，如果没找到，就提示用户没有该联系人
        query?.let {
            val contact = dbHelper.queryContactByName(it)
            if (contact != null) {
                val intent = Intent(this, zxkViewActivity::class.java)
                intent.putExtra("contactId", contact.id)
                startActivity(intent)
            } else {
                Toast.makeText(this,"暂无此联系人", Toast.LENGTH_SHORT).show()
            }
        }
        return true
    }

    override fun onQueryTextChange(newText: String?): Boolean {
        //当用户输入搜索文本时，不做任何操作，返回false表示不处理该事件
        return false
    }
}
