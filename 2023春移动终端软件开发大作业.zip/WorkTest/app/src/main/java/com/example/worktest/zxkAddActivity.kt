package com.example.worktest

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton

class zxkAddActivity : AppCompatActivity() {

    private lateinit var dbHelper: zxkDBHelper //数据库帮助类对象

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.zxkactivity_add)

        dbHelper = zxkDBHelper(this) //初始化数据库帮助类对象

        findViewById<FloatingActionButton>(R.id.btn_save).setOnClickListener {
            //创建一个AlertDialog.Builder对象
            val builder = AlertDialog.Builder(this)
            //设置对话框的标题和内容
            builder.setTitle("保存联系人")
            builder.setMessage("确定要保存联系人吗？")
            //设置对话框的正面按钮，点击时执行保存操作
            builder.setPositiveButton("确定") { dialog, which ->
                //获取输入框中的内容，并封装成一个Contact对象
                val name = findViewById<EditText>(R.id.et_name).text.toString().trim()
                val phone = findViewById<EditText>(R.id.et_phone).text.toString().trim()
                val email = findViewById<EditText>(R.id.et_email).text.toString().trim()
                val address = findViewById<EditText>(R.id.et_address).text.toString().trim()
                val relation = findViewById<EditText>(R.id.et_relation).text.toString().trim()
                val contact = zxkContact(0, name, phone, email, address, relation)

                //判断输入框中的内容是否为空，如果不为空，就调用数据库帮助类的insertContact方法，将联系人对象插入到数据库中
                if (name.isNotEmpty() && phone.isNotEmpty() && email.isNotEmpty() && address.isNotEmpty() && relation.isNotEmpty()) {
                    dbHelper.insertContact(contact)
                    Toast.makeText(this,"保存成功",Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this,"请填写完整信息",Toast.LENGTH_SHORT).show()
                }
            }
            //设置对话框的反面按钮，点击时取消对话框
            builder.setNegativeButton("取消") { dialog, which ->
                dialog.dismiss() //关闭对话框
            }
            //显示对话框
            builder.show()
        }

        findViewById<FloatingActionButton>(R.id.btn_exit).setOnClickListener{
            finish()
        }
    }
}
