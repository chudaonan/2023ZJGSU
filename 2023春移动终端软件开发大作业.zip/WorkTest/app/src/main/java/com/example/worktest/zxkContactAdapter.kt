package com.example.worktest

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class zxkContactAdapter(val context: Context, var dataList: List<zxkContact>) : RecyclerView.Adapter<zxkContactAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        //定义一个内部类ViewHolder，用来缓存itemView中的控件对象
        val tvName = itemView.findViewById<TextView>(R.id.tv_name)
        val tvPhone = itemView.findViewById<TextView>(R.id.tv_phone)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        //重写onCreateViewHolder方法，用来创建ViewHolder对象，并返回
        val view = LayoutInflater.from(context).inflate(R.layout.zxkitem_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        //重写onBindViewHolder方法，用来绑定数据到ViewHolder对象上，并设置点击事件监听器
        val contact = dataList[position] //获取当前位置的联系人对象
        holder.tvName.text = contact.name //设置姓名文本框的内容为联系人的姓名
        holder.tvPhone.text = contact.phone //设置电话文本框的内容为联系人的电话

        holder.itemView.setOnClickListener {
            //点击itemView时，跳转到查看联系人界面，并传递联系人的id
            val intent = Intent(context, zxkViewActivity::class.java)
            intent.putExtra("contactId", contact.id)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        //重写getItemCount方法，用来返回数据列表的大小
        return dataList.size
    }

    override fun getItemViewType(position: Int): Int {
        //根据位置返回不同的视图类型，这里只有一种视图类型，所以直接返回0
        return 0
    }

}
