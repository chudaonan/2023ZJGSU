package com.example.worktest

import android.annotation.SuppressLint
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.appcompat.app.AppCompatActivity

class zxkDBHelper(context: AppCompatActivity) : SQLiteOpenHelper(context, "contacts.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table contacts(" +
                "id integer primary key autoincrement, " +
                "name text, " +
                "phone text, " +
                "email text, " +
                "address text, " +
                "relation text)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }

    fun insertContact(contact: zxkContact) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", contact.name)
        values.put("phone", contact.phone)
        values.put("email", contact.email)
        values.put("address", contact.address)
        values.put("relation", contact.relation)
        db.insert("contacts", null, values)
        db.close()
    }

    fun deleteContact(id: Int) {
        val db = writableDatabase
        db.delete("contacts", "id = ?", arrayOf(id.toString()))
        db.close()
    }

    fun updateContact(contact: zxkContact) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", contact.name)
        values.put("phone", contact.phone)
        values.put("email", contact.email)
        values.put("address", contact.address)
        values.put("relation", contact.relation)
        db.update("contacts", values, "id = ?", arrayOf(contact.id.toString()))
        db.close()
    }

    @SuppressLint("Range")
    fun queryAllContacts(): List<zxkContact> {
        val db = readableDatabase
        val cursor = db.query("contacts", null, null, null, null, null, null)
        val list = mutableListOf<zxkContact>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val phone = cursor.getString(cursor.getColumnIndex("phone"))
            val email = cursor.getString(cursor.getColumnIndex("email"))
            val address = cursor.getString(cursor.getColumnIndex("address"))
            val relation = cursor.getString(cursor.getColumnIndex("relation"))
            list.add(zxkContact(id, name, phone, email, address, relation))
        }
        cursor.close()
        db.close()
        return list
    }

    @SuppressLint("Range")
    fun queryContactById(id: Int): zxkContact? {
        val db = readableDatabase
        val cursor = db.query("contacts", null, "id = ?", arrayOf(id.toString()), null, null, null)
        var contact: zxkContact? = null
        if (cursor.moveToFirst()) {
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val phone = cursor.getString(cursor.getColumnIndex("phone"))
            val email = cursor.getString(cursor.getColumnIndex("email"))
            val address = cursor.getString(cursor.getColumnIndex("address"))
            val relation = cursor.getString(cursor.getColumnIndex("relation"))
            contact = zxkContact(id, name, phone, email, address, relation)
        }
        cursor.close()
        db.close()
        return contact
    }

    @SuppressLint("Range")
    fun queryContactByName(name: String): zxkContact? {
        val db = readableDatabase
        val cursor = db.query(
            "contacts",
            null,
            "name = ?",
            arrayOf(name),
            null,
            null,
            null
        )
        var contact: zxkContact? = null
        if (cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val phone = cursor.getString(cursor.getColumnIndex("phone"))
            val email = cursor.getString(cursor.getColumnIndex("email"))
            val address = cursor.getString(cursor.getColumnIndex("address"))
            val relation = cursor.getString(cursor.getColumnIndex("relation"))
            contact = zxkContact(id, name, phone, email, address, relation)
        }
        cursor.close()
        db.close()
        return contact
    }
}