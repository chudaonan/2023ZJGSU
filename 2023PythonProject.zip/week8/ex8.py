import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn.neural_network import MLPClassifier

path = "C:\\Users\\lumic\\Desktop\\Python\\实验8 文本分类预测实验\\"
train_data = pd.read_csv(path+'review_train.csv', header=None, names=['评分', '标题', '评论'])
test_data = pd.read_csv(path+'review_test.csv', header=None, names=['标题', '评论'])
train_data['文本'] = train_data['标题'] + ' ' + train_data['评论']
test_data['文本'] = test_data['标题'] + ' ' + test_data['评论']
vectorizer = TfidfVectorizer()
X_train = vectorizer.fit_transform(train_data['文本'])
y_train = train_data['评分']
X_test = vectorizer.transform(test_data['文本'])
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)
model = MLPClassifier(hidden_layer_sizes=(128, 64), random_state=42)
model.fit(X_train, y_train)
y_val_pred = model.predict(X_val)
f1 = f1_score(y_val, y_val_pred, average='micro')
print(f'F1 Score: {f1}')
y_test_pred = model.predict(X_test)
with open(path+'pred.txt', 'w') as f:
    for pred in y_test_pred:
        f.write(f'{pred}\n')