import csv

path="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\data.csv"
with open(path,'r') as f:
    reader=csv.reader(f)
    avr_age=0
    avr_grade=0
    count=0
    for i in reader:
        count+=1
        print("{}:{},{}:{},{}:{},{}:{}".format("姓名",i[0],'性别',i[1],'年龄',i[2],'成绩',i[3]))
        avr_age+=float(i[2][:2])
        avr_grade+=float(i[3])
    avr_age/=count
    avr_grade/=count
print("平均年龄:",avr_age,"平均成绩:",avr_grade)