resoult="ID".rjust(5)
aa20 = {'A': 0, 'R': 0, 'N': 0, 'D': 0, 'C': 0, 'Q': 0, 'E': 0, 'G': 0, 'H': 0, 'I': 0, 'L': 0, 'K': 0, 'M': 0,
        'F': 0, 'P': 0, 'S': 0, 'T': 0, 'W': 0, 'Y': 0, 'V': 0}
for chr in aa20.keys():
    resoult+=chr.rjust(5)
resoult+='\n'
with open("C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\seqs_fasta.txt","r") as f:
    ls=f.read().split('>')
    ls.pop(0)
    r_dict={}
    for i in ls:
        aa20 = {'A': 0, 'R': 0, 'N': 0, 'D': 0, 'C': 0, 'Q': 0, 'E': 0, 'G': 0, 'H': 0, 'I': 0, 'L': 0, 'K': 0, 'M': 0,
                'F': 0, 'P': 0, 'S': 0, 'T': 0, 'W': 0, 'Y': 0, 'V': 0}
        i=i.split("\n")
        ID=i.pop(0)
        resoult+=ID.rjust(5)
        r_dict[ID]=aa20
        count=0
        for j in i:
            for chr in j:
                aa20[chr]+=1
                count+=1
        for frequency in aa20.values():
            resoult+=str(round(frequency*100/count,1)).rjust(5)
        resoult+='\n'
print(resoult)
with open("C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\result6.txt",'w') as r:
    r.write(resoult)