with open("C:\\Users\\lumic\\Desktop\Python\实验3 文件操作与数据存取\\info_stocks.txt","r") as f:
    ls=[]
    for i in f:
        ls.append(i.strip("\n").split(','))

def sumPrice(ls_element):
    shares=int(ls_element[1].split(':')[1])
    price=float(ls_element[2].split(':')[1])
    sum=shares*price
    return sum

ls.sort(key=lambda le_element:sumPrice(le_element),reverse=True)

def Print(ls_element):
    print(ls_element[0],ls_element[2],"'sumPrice':",sumPrice(ls_element))

filter_ls=filter(lambda ele:float(ele[2].split(':')[1])>80,ls)

print("Q(a)")
for i in ls:
    Print(i)
print("Q(b)")
for i in filter_ls:
    Print(i)

