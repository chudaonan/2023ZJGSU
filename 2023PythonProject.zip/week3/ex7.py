import os
import shutil

path="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\"
path_old=path+"oldfilename.txt"
path_new=path+"newfilename.txt"
f=open(path_old,'a')
f.close()
os.rename(path_old,path_new)
path2=(path+"folder\\")
if not os.path.exists(path2):
    os.mkdir(path2)
shutil.move(path_new,path2)