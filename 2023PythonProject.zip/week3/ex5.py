import os
import shutil

path="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\"
path2=path+"ex5\\"
f_list=os.listdir(path2)
ls=[]
for i in f_list:
    if i.endswith(".py"):
        ls.append(i)
print(ls)
for i in ls:
    shutil.copy(path2+i,path+"ex5_dst\\")
shutil.make_archive(path+'ex\\','zip',path+"ex5_dst\\")

