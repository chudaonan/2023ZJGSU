import math

def euclidDist(A,B):
    return math.sqrt(pow(float(A[1])-float(B[1]),2)+pow(float(A[2])-float(B[2]),2)+pow(float(A[3])-float(B[3]),2))

def manhattanDist(A,B):
    return abs(float(A[1])-float(B[1]))+abs(float(A[2])-float(B[2]))+abs(float(A[3])-float(B[3]))

def chebyshevDist(A,B):
    return max(abs(float(A[1])-float(B[1])),abs(float(A[2])-float(B[2])),abs(float(A[3])-float(B[3])))


with open("C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\points.txt","r") as f:
    ls=[]
    for i in f:
        ls.append(i.strip("\n").split(","))

euclidMax=0
euclidMaxPointA=0
euclidMaxPointB=0
manhattanMax=0
manhattanPointA=0
manhattanPointB=0
chebyshevMax=0
chebyshevPointA=0
chebyshevPointB=0
for A in ls:
    for B in ls:
        if euclidDist(A,B)>euclidMax:
            euclidMax=euclidDist(A,B)
            euclidMaxPointA=A[0]
            euclidMaxPointB=B[0]
r1=("欧氏距离最大值："+"%.3f"%euclidMax+","+"距离最远的两点："+euclidMaxPointA+","+euclidMaxPointB)
for A in ls:
    for B in ls:
        if manhattanDist(A,B)>manhattanMax:
            manhattanMax=manhattanDist(A,B)
            manhattanPointA=A[0]
            manhattanPointB=B[0]
r2=("曼哈顿距离最大值："+"%.3f"%manhattanMax+","+"距离最远的两点："+manhattanPointA+","+manhattanPointB)
for A in ls:
    for B in ls:
        if chebyshevDist(A,B)>chebyshevMax:
            chebyshevMax=chebyshevDist(A,B)
            chebyshevPointA=A[0]
            chebyshevPointB=B[0]
r3=("切比雪夫距离最大值："+"%.3f"%chebyshevMax+","+"距离最远的两点："+chebyshevPointA+","+chebyshevPointB)
with open("C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\result5.txt",'w') as r:
    r.write(r1)
    r.write('\n')
    r.write(r2)
    r.write('\n')
    r.write(r3)