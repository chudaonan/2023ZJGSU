path1="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\compare1.txt"
path2="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\compare2.txt"
with open(path1,'r',encoding="utf-8") as f:
    f1=f.readlines()
with open(path2,'r',encoding="utf-8") as f:
    f2=f.readlines()
a=[]
b=[]
for i in f1:
    for j in i:
        if j!='\n':
            a.append(j)
f1=a
for i in f2:
    for j in i:
        if j!='\n':
            b.append(j)
f2=b
resoult="OK!"
if len(f1)!=len(f2):
    resoult="NO!"
else:
    for i in range(len(f1)):
        if f1[i]!=f2[i]:
            resoult="NO!"
            break
print(resoult)