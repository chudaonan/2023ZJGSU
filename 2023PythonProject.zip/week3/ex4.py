import os
import pickle
import shutil

path="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\"
path2=(path+"mkdir\\")
if not os.path.exists(path2):
    os.mkdir(path2)
f_list=os.listdir(path)
for i in f_list:
    if i.startswith("news_"):
        shutil.move(path+i,path2)
f_new_list=os.listdir(path2)
def wordcount(w,textfile):
    with open(textfile,'r') as f:
        str=f.read()
    return str.count(w)
with open(path2 + "wc.pkl", 'wb') as f_out:
    pickle.dump((wordcount, f_new_list), f_out)
with open(path2 + "wc.pkl", 'rb') as f_input:
    obj=pickle.load(f_input)

words=["中国","美国","科技","芯片"]
for i in ['']+words:
    print(i.ljust(20),end='')
print()
for f in obj[1]:
    with open(f,'r') as file:
        if file.name.startswith("news_"):
            print(file.name.ljust(20),end=' ')
            for word in words:
                frequency=wordcount(word,path2+file.name)
                frequency=str(frequency)
                print(frequency.ljust(20),end=" ")
        print()