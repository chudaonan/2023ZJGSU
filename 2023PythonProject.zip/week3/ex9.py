import time

accountAdmin="张三"
passwordAdmin="123456"
def get_formatted_time():
    return  time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
path="C:\\Users\\lumic\\Desktop\\Python\\实验3 文件操作与数据存取\\log.txt"
def log_record(account,password,log_state):
    with open(path,'a') as f:
        f.write(account+','+password+','+get_formatted_time()+','+log_state+'\n')
def look_log():
    with open(path,'r') as f:
        r=f.readlines()
        print(r)
def login():
    account=input("pls input the account:")
    password=input("pls input the password:")
    log_state=''
    if account==accountAdmin and password==passwordAdmin:
        log_state="登录成功"
        log_record(account,password,log_state)
    else:
        log_state = "登录失败"
        log_record(account, password, log_state)

if __name__=="__main__":
    while True:
        sel = input("请输入你的操作：1--登录，2--查看日志，其他--退出 :")
        if sel==str(1):
            login()
        elif sel==str(2):
            look_log()
        else:
            break
