import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC

path = "C:\\Users\\lumic\\Desktop\\Python\\实验6 数据挖掘分类入门实验\\"
train_data = pd.read_csv(path+"data-train.csv")
test_data = pd.read_csv(path+"data-test.csv")

train_features = train_data.drop('target', axis=1)
test_features = test_data.drop('target', axis=1)

train_labels = train_data['target']
test_labels = test_data['target']

rfc = RandomForestClassifier()

rfc.fit(train_features, train_labels)

predictions = rfc.predict(test_features)

f1_scores = cross_val_score(rfc, train_features, train_labels, cv=5, scoring='f1_macro')

print("mean f1 score:", f1_scores.mean())

# svm = SVC()
#
# f1_scores = cross_val_score(svm, train_features, train_labels, cv=5, scoring='f1_macro')
#
# print("mean f1 score:", f1_scores.mean())
#
# predictions = svm.predict(test_features)


with open(path+"predictions.txt", 'w') as f:
    for i in predictions:
        f.write(i + '\n')
