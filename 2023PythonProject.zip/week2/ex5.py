ls=[11,22,33,44,55,66,77,88,99,100,110,200,230,330]
v1=[]
v2=[]
v3=[]
for i in ls:
    if i>66:
        v1.append(i)
    else:
        v2.append(i)
    if i%2!=0:
        v3.append(i)
dict={"k1":v1,"k2":v2,"k3":v3}
print(dict)
sum=0
for i in dict["k3"]:
    sum+=i*i
print(sum)
