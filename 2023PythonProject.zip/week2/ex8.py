year = input("请输入年：")
month = input("请输入月：")
day = input("请输入日：")
arr = [31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
if (int(year) % 4 == 0 and int(year) % 100 != 0) or int(year) % 400 == 0:
    arr[1] = 29
else:
    arr[1] = 28
sum = 0
for i in range(int(month)-1):
    sum = sum + arr[i]
sum = sum + int(day)
print(sum)