def factorization(num):
    divisor=[]
    index=[]
    for i in range(2,num):
        if num%i==0:
            divisor.append(i)
            indexNum=0
            while num%i==0:
                indexNum+=1
                num//=i
            index.append(indexNum)
    if num > 1:
        divisor.append(num)
        index.append(1)
    return divisor,index
num=int(input("请输入一个正整数："))
divisor,index=factorization(num)
result=[]
result.append(divisor)
result.append(index)
print(result)
