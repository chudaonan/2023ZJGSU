def addBinary(a,b):
    s=bin(int(a,2)+int(b,2)).replace('0b','')
    return s
a=input('请输入一个二进制字符串：')
b=input('请输入一个二进制字符串：')
print(addBinary(a,b))