import random

i1=random.randint( 1, 7)
i2=random.randint( 1, 7)
sum=i1+i2
if sum==7 or sum==11:
    print("玩家胜")
elif sum==2 or sum==3 or sum==12:
    print('庄家胜')
else:
    sum1=sum
    while 1:
        i1 = random.randint(1, 7)
        i2 = random.randint(1, 7)
        sum = i1 + i2
        if sum==sum1:
            print("玩家胜")
            break
        if sum==7:
            print('庄家胜')
            break
