def count(str):
    superCount = []
    lowerCount = []
    digitCount = []
    othersCount = []
    for i in str:
        if i.isupper():
            superCount.append(i)
        elif i.islower():
            lowerCount.append(i)
        elif i.isdigit():
            digitCount.append(i)
        else:
            othersCount.append(i)
    return tuple(superCount),tuple(lowerCount),tuple(digitCount),tuple(othersCount)

str=input("请输入一个字符串：")
superCount,lowerCount,digitCount,othersCount=count(str)
print("大写字母的个数：",len(superCount))
print("小写字母的个数：",len(lowerCount))
print("数字的个数：",len(digitCount))
print("其他字符的个数：",len(othersCount))
print(superCount)
print(lowerCount)
print(digitCount)
print(othersCount)
