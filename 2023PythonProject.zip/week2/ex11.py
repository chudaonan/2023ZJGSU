import math

def t(x):
    if math.sqrt(x)%1==0:
        return x

list=list(filter(t,range(1,10001)))
print(list)