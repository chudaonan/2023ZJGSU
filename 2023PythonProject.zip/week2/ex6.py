from functools import reduce


def charToInt(s):
    digits={'0':0,'1':1,'2':2,'3':3,'4':4,'5':5,'6':6}
    return digits[s]

def str2float(s):
    ss=s.split('.',1)
    sss1=list(map(charToInt,ss[0]))
    sss2=list(map(charToInt,ss[1]))
    i1=reduce(lambda x,y:x*10+y,sss1)
    i2=reduce(lambda x,y:x*10+y,sss2)*0.1**len(sss2)
    return i1+i2
s='123.456'
print(str2float(s))