import math

def mymath(a,b,c):
    return math.e**(b**((1.0*math.pi/2)**0.5))+1.0*(-b+(b**2-4*a*c)**0.5)/(2*a)+1.0*(math.log(abs(a+b),10)+1.0*a/b)/math.log(a**b+100,math.e)
print(mymath(3,4,1))