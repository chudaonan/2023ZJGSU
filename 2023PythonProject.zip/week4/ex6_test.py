from mp import student

stu1=student("stu1",17,'men',88,89,90)
stu2=student("stu2",18,'men',88,89,90,91)
stu3=student("stu3",19,'women',88,89,90,91,92)
print(stu1.avg_grades())
stu2.set_age(20)
print(stu2.get_age())
print(stu3.get_grades()[2])
