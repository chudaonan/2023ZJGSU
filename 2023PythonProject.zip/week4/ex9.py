class SchoolPerson():
    def __init__(self,name,gender,age):
        self.name=name
        self.gender=gender
        self.age=age

class Student(SchoolPerson):
    def __init__(self,name,gender,age,stu_class,sno):
        super().__init__(name,gender,age)
        self.stu_class=stu_class
        self.sno=sno

    def print_info(self):
        print(self.name,self.gender,self.age,self.stu_class,self.sno)

class Teacher(SchoolPerson):
    def __init__(self,name,gender,age,department,cno):
        super().__init__(name,gender,age)
        self.deparment=department
        self.cno=cno

    def print_info(self):
        print(self.name,self.gender,self.age,self.deparment,self.cno)

if __name__=='__main__':
    stu=Student('stu1','man',18,'class1','No.1')
    tea=Teacher('tea3','woman',33,'deparment3','No.3')
    stu.print_info()
    tea.print_info()