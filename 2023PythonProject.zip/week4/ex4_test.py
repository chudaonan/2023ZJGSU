from mypack.subpack.bb import sub
from mypack.aa import add
from mypack import a,b

m=4
n=3
sub(m,n)
add(m,n)
add(a,b)