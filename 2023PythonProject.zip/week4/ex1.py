import datetime
import time

print(time.time())

print(datetime.date.today())
print(datetime.date.today()-datetime.timedelta(30))