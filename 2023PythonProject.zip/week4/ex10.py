import math


class MyMath():
    def __init__(self,radius):
        self.r=radius

    def get_circumference_of_a_circle(self):
        return 2*math.pi*self.r

    def get_surfaceArea_of_a_circle(self):
        return math.pi*(self.r**2)

    def get_surfaceArea_of_a_sphere(self):
        return 4*math.pi*self.r**2

    def get_volume_of_a_sphere(self):
        return 4/3*math.pi*self.r**3

if __name__=='__main__':
    r=input('请输入半径：')
    if r.isdigit():
        r=float(r)
        mymath=MyMath(r)
        print("圆的周长:%.2f,圆的面积%.2f"%(mymath.get_circumference_of_a_circle(),mymath.get_surfaceArea_of_a_circle()))
        print("球的表面积:%.2f,球的体积:%.2f"%(mymath.get_surfaceArea_of_a_sphere(),mymath.get_volume_of_a_sphere()))
    else:
        print('请输入数字！')
