import math


class Cylinder():
    def __init__(self,radius,height):
        self.r=radius
        self.h=height

    def GetVolume(self):
        volume=math.pi*(self.r**2)*self.h
        return volume

if __name__=='__main__':
    r=float(input("请输入半径："))
    h=float(input("请输入高："))
    cylinder=Cylinder(r,h)
    print('radius:%.2f,height:%.2f' % (cylinder.r, cylinder.h))
    print('volume:%.2f' % cylinder.GetVolume())