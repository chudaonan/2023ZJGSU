def add(x,y):
    print(x+y)