def sub(x,y):
    print(x-y)