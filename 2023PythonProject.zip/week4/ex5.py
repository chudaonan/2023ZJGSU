class Counter():
    publicCount=0
    __secretCount=0
    def count(self):
        self.publicCount+=1
        self.__secretCount+=1
        print(self.__secretCount)

counter=Counter()
counter.count()
print(counter._Counter__secretCount)