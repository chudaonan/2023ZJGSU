class person():
    def __init__(self, name, age, sex):
        self.__name = name
        self.__age = age
        self.__sex = sex

    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def get_age(self):
        return self.__age

    def set_age(self, age):
        self.__age = age

    def get_sex(self):
        return self.__sex

    def set_sex(self, sex):
        self.__sex = sex

class student(person):
    def __init__(self,name,age,sex,*grades):
        super().__init__(name,age,sex)
        self.grades=grades

    def get_grades(self):
        return self.grades

    def set_grades(self,*grades):
        self.grades=grades

    def avg_grades(self):
        sum=0
        for i in self.grades:
            sum+=i
        avg=sum/len(self.grades)
        return avg
