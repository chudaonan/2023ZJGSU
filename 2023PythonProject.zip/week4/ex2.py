import os
import random

dirname="C:\\Users\\lumic\\Desktop\\Python\\实验4_模块与面向对象编程\\ex2\\"
s="ex2"
def fs(dirname,s):
    file_list=[]
    for i in os.listdir(dirname):
        if i.endswith(".txt"):
            file_list.append(i)

    if len(file_list)==0:
        with open(dirname+"new.txt",'a') as f:
            f.writelines(s+'\n')
    else:
        r=random.randint(0,len(file_list)-1)
        with open(dirname+file_list[r],'a') as f:
            f.writelines(s+'\n')
fs(dirname,s)