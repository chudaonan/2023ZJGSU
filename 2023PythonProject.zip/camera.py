#使用 OpenCV 提供的基于 Haar 级联的人脸检测器
import cv2

# 加载预训练的人脸检测模型
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# 读取摄像头
cap = cv2.VideoCapture(0)

# 创建一个视频写入对象
fourcc = cv2.VideoWriter_fourcc(*'XVID') # 定义编码格式
out = cv2.VideoWriter('video.avi', fourcc, 20.0, (640, 480)) # 定义输出文件名，帧率和分辨率

# 循环处理每一帧
while True:
   # 读取一帧
   ret, frame = cap.read()
   # 转换颜色空间为灰度
   gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
   # 检测人脸
   faces = face_cascade.detectMultiScale(gray, 1.3, 5)
   # 对每个检测到的人脸绘制矩形框
   for (x,y,w,h) in faces:
       frame = cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
   # 将带有人脸框的图像写入视频文件
   out.write(frame)
   # 显示视频帧
   cv2.imshow('frame',frame)
   # 等待用户按键
   if cv2.waitKey(1) & 0xFF == ord('e'):
       break
# 释放资源
cap.release()
out.release()
cv2.destroyAllWindows()
