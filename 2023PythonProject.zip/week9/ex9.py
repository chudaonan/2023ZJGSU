import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split

path = "C:\\Users\\lumic\\Desktop\\Python\\实验9 多分类手写数字识别实验\\"
train_data = pd.read_csv(path + "train_data.csv", dtype="uint8")
X_train = train_data.iloc[:, 1:].values / 255
y_train = train_data.iloc[:, 0].values

test_data = pd.read_csv(path + "test_data.csv", dtype="uint8")
X_test = test_data.values / 255

X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

clf = SVC(kernel="rbf", gamma="scale", C=10)
clf.fit(X_train, y_train)

y_pred_val = clf.predict(X_val)

acc_val = (y_pred_val ==y_val).mean()
print("验证集准确率：", acc_val)

y_pred_test = clf.predict(X_test)

with open(path + "preds.txt", "w") as f:
    for label in y_pred_test:
        f.write(str(label) + "\n")