# 从用户输入中获取一个长度为5的字符串
s1 = input("请输入长度为5的字符串：")

# 将字符串转换成列表
s2 = list(s1)

# 将列表反转
s1 = list(s1)
s1.reverse()

# 判断是否为回文串
if s1 == s2:
    print("是回文串")
else:
    print("不是回文串")