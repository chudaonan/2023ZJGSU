help(pow)

# 使用内置函数 pow() 计算 3 的 2 次方
pow(3, 2)

# 使用运算符 ** 计算 3 的 2 次方
3 ** 2

import math

# 使用 math 模块中的 pow() 函数计算 3 的 2 次方
math.pow(3, 2)

# 使用 math 模块中的 log() 函数计算以 10 为底 2 的对数
math.log(2, 10)

# 使用 math 模块中的 log() 函数计算以 2 为底 2 的对数
math.log(2, 2)

# 创建包含数学函数的列表
funs = [math.log, math.exp, math.sin, math.cos, math.tan]

# 循环遍历列表中的函数，并将 1 到 5 之间的整数作为参数传入
for i in range(1, 6):
    # 调用当前函数，并传入 i 作为参数，然后将结果打印出来
    print(funs[i-1](i))