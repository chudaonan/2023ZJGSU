x=10
y=20
z=x+y
print('X','=',x)
print('Y',y,sep='=')
print('Sum=',z)
print(x,y,sep='+',end='=');
print(z)
print(x,y)
#sep -- 用来间隔多个对象，默认值是一个空格。
#end -- 用来设定以什么结尾,默认值是换行符 \n.
#       我们可以换成其他字符串；“end=' '”意思是末尾不换行，加空格。