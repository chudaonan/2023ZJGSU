import time

# 获取当前本地时区的时间
i = time.localtime(time.time())

# 将当前时间格式化为 "YYYY-MM-DD HH:MM:SS" 的格式并打印
print(time.strftime('%Y-%m-%d %H:%M:%S', i))

import datetime

# 创建一个代表当前日期和时间的 datetime 对象
j = datetime.datetime.now()

# 打印 datetime 对象本身
print(j)

# 打印由连字符分隔的 datetime 对象的年、月和日
print(j.year, j.month, j.day, sep='-')

# 打印由冒号分隔的 datetime 对象的小时、分钟和秒
print(j.hour, j.minute, j.second, sep=':')