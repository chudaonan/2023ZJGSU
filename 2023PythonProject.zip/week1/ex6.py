s="helllo12345aa*&@*"
alpha=0
digit=0
other=0
for i in s:
    if i.isalpha():
        alpha+=1
    elif i.isdigit():
        digit+=1
    else:
        other+=1
print(s,"中的英文字母个数为：",alpha)
print(s,"中的数字个数为：",digit)
print(s,"中的其他字符个数为：",other)