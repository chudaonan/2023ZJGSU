count=0
num=66
while 1:
    n=int(input("请输入一个数字："))
    if n>num:
        count+=1
        print("猜测的结果大了,请再次猜测：")
    elif n<num:
        count+=1
        print("猜测的结果小了,请再次猜测：")
    else:
        count+=1
        print("猜测结果正确")
        print("总共猜测的次数：",count)
        break