import numpy as np

a=np.mat([[1,2,3],
          [3,4,5],
          [4,5,6]])
print(a[0,0]+a[1,1]+a[2,2])
