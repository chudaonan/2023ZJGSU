m=int(input("请输入m(m+100<n)"))
n=int(input("请输入n(m+100<n)"))
count=0
if(m>=2):
    for i in range(m,n+1):
        Break=0;
        for j in range(2,i//2+1):
            if(i%j==0):
                Break=1
                break
        if(Break==0):
            print(i)
            count+=1
print(m,"~",n,"之间素数的个数:",count)