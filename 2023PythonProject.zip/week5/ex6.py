from pandas import DataFrame

data={'性别':['男',  '女',  '女',  '男',  '男'],
      '姓名':['小明','小红','小芳','大黑','张三'],
      '年龄':['20',  '21',  '25', '24',  '29']}
data=DataFrame(data)
print(data,'\n')
print(data.iloc[0,0],'\n')
print(data.head(3),'\n')
print(data.describe(),'\n')
print(data.values)