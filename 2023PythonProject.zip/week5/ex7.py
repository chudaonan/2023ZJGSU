from pandas import DataFrame

data={'dataset':['I','I','I','I','I'],
      'x':[10.0,8.0,13.0,9.0,11.0],
      'y':[8.04,6.95,7.58,8.81,8.33]}
data=DataFrame(data)
print(data,'\n')
data.loc[[2,4],'dataset']='II'
print(data,'\n')
print(data.groupby('dataset').mean(),'\n')
print(data[data['x']>9.5]['y'].mean())