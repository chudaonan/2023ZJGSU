import matplotlib.pyplot as plt
import numpy as np

data1 = np.random.randint(0, 10, size=5)
data2 = np.random.randint(0, 10, size=5)
data3 = np.random.randint(0, 10, size=5)
data4 = np.random.randint(0, 10, size=5)
data5 = np.random.randint(0, 10, size=5)

fig,axs=plt.subplots(nrows=3,ncols=2)

axs[0][0].bar(range(len(data1)), data1)
axs[0][0].set_title('柱状图')

axs[0][1].scatter(range(len(data2)), data2)
axs[0][1].set_title('散点图')

axs[1][0].pie(data3)
axs[1][0].set_title('饼图')

axs[1][1].plot(range(len(data4)), data4)
axs[1][1].set_title('折线图')

axs[2][0].hist(data5)
axs[2][0].set_title('直方图')
plt.show()