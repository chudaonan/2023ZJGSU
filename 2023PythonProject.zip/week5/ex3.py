import numpy as np

matrix=np.random.uniform(10,20,(10,5))
print(matrix)
print()
# matrix -= np.mean(matrix, axis=1).reshape(-1, 1)
matrix -= np.mean(matrix, axis=1,keepdims=True)
print(matrix)
print()
np.savetxt("C:\\Users\\lumic\\Desktop\\Python\\实验5 Python科学计算实践\\dat.csv",matrix,fmt="%.3f",delimiter=",")
data = np.loadtxt("C:\\Users\\lumic\\Desktop\\Python\\实验5 Python科学计算实践\\dat.csv", delimiter=",")
print(data)
print()
data[[0,1],:]=data[[1,0],:]
print(data)
print()
data=data[data[:,1].argsort()]
print(data)