import timeit
import numpy as np
import math


def myfunc(x):
    return math.cos(x)

umyfun=np.frompyfunc(myfunc,1,1)

start_time=timeit.default_timer()
umyfun(np.arange(1, 100001))
print("Time taken by umyfun():", timeit.default_timer() - start_time)

start_time = timeit.default_timer()
np.cos(np.arange(1, 100001))
print("Time taken by np.cos():", timeit.default_timer() - start_time)