import numpy as np
from scipy import integrate

def fun(x):
    return x**2+np.sin(x)+np.sqrt(x)+x**(1/3)+1

resoult,error=integrate.quad(fun,1,2)
print(resoult)