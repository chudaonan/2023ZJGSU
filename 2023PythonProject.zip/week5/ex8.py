import matplotlib.pyplot as plt
from pandas import DataFrame

data = {'姓名': ['张三', '李四', '王五'],
        '年龄': [20, 21, 22],
        '成绩': [80, 90, 100]}
data=DataFrame(data)
mean_score=data['成绩'].mean()
mean_age=data['年龄'].mean()
score=data.plot(kind='bar',x='姓名',y='成绩')
score.axhline(mean_score,color='r')
age=data.plot(kind='bar',x='姓名',y='年龄')
age.axhline(mean_age,color='y',linestyle='--')
plt.show()