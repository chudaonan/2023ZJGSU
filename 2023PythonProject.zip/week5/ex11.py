import matplotlib.pyplot as plt
from pandas import DataFrame

data={'year':[1949,1949,1949,1949,1949,1949,1949,1949,1949,1949,1949,1949,],
      'month':['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      'passengers':[112,118,132,129,121,112,96,145,111,105,106,99]}
data=DataFrame(data)
data.plot(kind='bar',x='month',y='passengers')
plt.show()