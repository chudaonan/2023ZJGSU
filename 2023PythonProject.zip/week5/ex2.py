import numpy as np

A=np.random.uniform(-1,1,size=10000)
B=np.random.randn(10000)
print("A+B:",A+B)
print("A*B:",A*B)
print("A/B:",A/B)
print("exp(A)+exp(B):",np.exp(A)+np.exp(B))
print("A和B的内积:",np.dot(A,B))
print("B全体元素的平均值，最大值，最小值:",np.mean(B),np.max(B),np.min(B))