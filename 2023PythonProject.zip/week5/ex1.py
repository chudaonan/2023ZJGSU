import numpy as np

# 生成随机数组
array = np.random.randn(9, 10)

# (a) 使用索引方式获取第2行第5列、第6行第3列的元素
a1 = array[1, 4]
a2 = array[5, 2]

# (b) 使用切片方式获取第3行至第5行和第4列至第6列的数据
b = array[2:5, 3:6]

# (c) 使用切片与整数序列索引混合的方式，获取第3行至第5行且为第1列、第2列和第4列的数据
c = array[2:5, [0, 1, 3]]

# (d) 使用布尔索引方法将数组中取值大于1的元素重新赋值为10.00，小于-1的元素重新赋值为-10.00
array[array > 1] = 10.00
array[array < -1] = -10.00

# 打印输出结果
print("a1:", a1)
print("a2:", a2)
print("b:", b)
print("c:", c)
print("newArray:", array)