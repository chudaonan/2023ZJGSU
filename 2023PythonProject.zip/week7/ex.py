import numpy as np
import pandas as pd
from onedal.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import f1_score

path = "C:\\Users\\lumic\\Desktop\\Python\\实验7 蛋白质功能预测\\"

train_df = pd.read_csv(path+"ProSeqs_Train.txt", sep=" ", header=None)
test_df = pd.read_csv(path+"ProSeqs_Test.txt", sep=" ", header=None)

train_seqs = np.array(train_df.iloc[:, 2])
train_labels = np.array(train_df.iloc[:, 1])
test_seqs = np.array(test_df.iloc[:, 1])

def get_aa_composition(seqs):
    aa_composition = []
    for seq in seqs:
        aa_count = [0] * 20
        for aa in seq:
            if aa == 'A':
                aa_count[0] += 1
            elif aa == 'R':
                aa_count[1] += 1
            elif aa == 'N':
                aa_count[2] += 1
            elif aa == 'D':
                aa_count[3] += 1
            elif aa == 'C':
                aa_count[4] += 1
            elif aa == 'Q':
                aa_count[5] += 1
            elif aa == 'E':
                aa_count[6] += 1
            elif aa == 'G':
                aa_count[7] += 1
            elif aa == 'H':
                aa_count[8] += 1
            elif aa == 'I':
                aa_count[9] += 1
            elif aa == 'L':
                aa_count[10] += 1
            elif aa == 'K':
                aa_count[11] += 1
            elif aa == 'M':
                aa_count[12] += 1
            elif aa == 'F':
                aa_count[13] += 1
            elif aa == 'P':
                aa_count[14] += 1
            elif aa == 'S':
                aa_count[15] += 1
            elif aa == 'T':
                aa_count[16] += 1
            elif aa == 'W':
                aa_count[17] += 1
            elif aa == 'Y':
                aa_count[18] += 1
            elif aa == 'V':
                aa_count[19] += 1
            else:
                aa_count[19] += 1  # 非标准氨基酸记为V
        aa_composition.append(aa_count)
    return np.array(aa_composition)

train_aa_composition = get_aa_composition(train_seqs)
test_aa_composition = get_aa_composition(test_seqs)

# svm = SVC(kernel='linear', C=1)
#
# svm.fit(train_aa_composition, train_labels)
#
# train_f1 = f1_score(train_labels, svm.predict(train_aa_composition), average='macro')
#
# print("Train F1 score: {:.4f}".format(train_f1))
#
# knn = KNeighborsClassifier()
#
# knn.fit(train_aa_composition, train_labels)
#
# train_f1 = f1_score(train_labels, knn.predict(train_aa_composition), average='macro')
#
# print("Train F1 score: {:.4f}".format(train_f1))

rfc = RandomForestClassifier()

rfc.fit(train_aa_composition, train_labels)

train_f1 = f1_score(train_labels, rfc.predict(train_aa_composition), average='macro')

print("Train F1 score: {:.4f}".format(train_f1))


pred_labels = rfc.predict(test_aa_composition)

np.savetxt(path+"preds.txt", pred_labels, fmt='%d')

