import re

string = 'aaa bbb ccc;ddd eee;fff'
result = re.split(';| ', string)
print(result)
