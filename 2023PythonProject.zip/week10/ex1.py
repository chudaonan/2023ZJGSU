import re

s="I like Python programming 123 because it is 456 simple and elegant."
pattern = r'\b\w*o\w*\b'
result = re.findall(pattern, s)
print(result)
# 这个表达式的意思是：
# \b 表示单词边界，用来匹配单词的开头或结尾。
# \w* 表示零个或多个字母、数字或下划线，用来匹配单词中的字符。
# o 表示字母’o’，用来匹配单词中含有’o’的部分。
# \w*\b 表示零个或多个字母、数字或下划线，后面跟着一个单词边界，用来匹配单词的结尾。
# 这个表达式可以匹配任何包含字母’o’的单词，不管’o’在单词中的位置。