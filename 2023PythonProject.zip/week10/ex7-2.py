import re

string = "I like  beijing."
words = re.split(' +', string)
reversed_words = reversed(words)
result = ' '.join(reversed_words)
print(result)
