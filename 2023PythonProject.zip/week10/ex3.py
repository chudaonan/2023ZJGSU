import re
s = """xiasd@163.com, sdlfkj@.com sdflkj@180.com solodfdsf@123.com sdlfjxiaori@139.com saldkfj.com oisdfo@.sodf.com.com"""
pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
# pattern = r'[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+'
result = re.findall(pattern, s)
print(result)
# 这个表达式的意思是：
# [a-zA-Z0-9.!#$%&\'*+/=?^_{|}~-]+` 表示一个或多个字母、数字或其他合法的字符，用来匹配邮件地址的本地部分。
# @ 表示一个@符号，用来分隔本地部分和域名部分。
# [a-zA-Z0-9-]+ 表示一个或多个字母、数字或连字符，用来匹配域名部分的第一段。
# (?:\.[a-zA-Z0-9-]+)+ 表示一个或多个由点号和字母、数字或连字符组成的段落，用来匹配域名部分的后续段落。
# 这个表达式可以匹配大多数常见的邮件地址格式，但不一定能覆盖所有可能的情况