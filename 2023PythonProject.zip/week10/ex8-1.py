import os
import urllib.request
from html.parser import HTMLParser

class MyHTMLParser(HTMLParser):
    def __init__(self, base_url):
        super().__init__()
        self.base_url = base_url
        self.img_urls = []

    def handle_starttag(self, tag, attrs):
        if tag == 'img':
            for attr in attrs:
                if attr[0] == 'src':
                    self.img_urls.append(urllib.parse.urljoin(self.base_url, attr[1]))

def download_images(url, save_path):
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    opener = urllib.request.build_opener()
    opener.addheaders = [('User-agent', 'Mozilla/5.0')]
    urllib.request.install_opener(opener)

    response = urllib.request.urlopen(url)
    html_content = response.read().decode('utf-8')

    parser = MyHTMLParser(url)
    parser.feed(html_content)

    for img_url in parser.img_urls:
        img_name = os.path.split(img_url)[1]
        try:
            urllib.request.urlretrieve(img_url, os.path.join(save_path, img_name))
            print(f"Image saved as {img_name}")
        except Exception as e:
            print(f"Failed to save image {img_name}: {e}")

if __name__ == "__main__":
    url = "https://m.huiyi8.com/fengjing/zuimei/"
    download_images(url, "C:\\Users\\lumic\\Desktop\\Python\\实验10 正则表达式与网络爬虫\\image1")