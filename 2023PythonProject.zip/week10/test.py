import random

# 随机生成一个包含 20 个不大于 100 的正整数的列表
numbers = [random.randint(1, 100) for i in range(20)]
print("生成的随机数列表为：", numbers)

# 将前 10 个元素升序排列
numbers[:10].sort()

# 将后 10 个元素降序排列
numbers[10:].sort(reverse=True)

# 输出排列后的结果
print("排列后的结果为：", numbers)