import re

def num_to_word(match):
    num_dict = {
        "0": "Zero",
        "1": "One",
        "2": "Two",
        "3": "Three",
        "4": "Four",
        "5": "Five",
        "6": "Six",
        "7": "Seven",
        "8": "Eight",
        "9": "Nine"
    }
    num = match.group()
    return num_dict[num]

string1 = "Hello1234World"
result1 = re.sub("\d", num_to_word, string1)
print(result1)

string2 = "My phone number is 123-456-7890"
result2 = re.sub("\d", num_to_word, string2)
print(result2)

string3 = "<h1>Hello</h1><p>World</p>"
result3 = re.sub("<[^>]+>", "", string3)
print(result3)

string4 = "<div class='container'><span>Python</span><span>Regex</span></div>"
result4 = re.sub("<[^>]+>", "", string4)
print(result4)