import re

def is_valid_phone_number(string):
    pattern = r'^1\d{2}-\d{4}-\d{4}$'
    if re.match(pattern, string):
        return True
    else:
        return False

def is_valid_date(string):
    pattern = r'^(19|20)\d{2}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$'
    if re.match(pattern, string):
        return True
    else:
        return False

def is_valid_postal_code(string):
    pattern = r'^\d{6}$'
    if re.match(pattern, string):
        return True
    else:
        return False

s=input("pls input sth: ")
print("是否是有效的手机号码: ",is_valid_phone_number(s))
print("是否是有效的日期: ",is_valid_date(s))
print("是否是有效的邮政编码: ",is_valid_postal_code(s))