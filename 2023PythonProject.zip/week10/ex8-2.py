import os
import requests
from bs4 import BeautifulSoup

def download_images(url, save_path):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
        "Referer": url
    }
    resp = requests.get(url=url, headers=headers)
    resp.encoding = "utf-8"
    resp_text = resp.text
    soup = BeautifulSoup(resp_text, 'html.parser')
    img_tags = soup.find_all("img")
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    for ipic in img_tags:
        href = ipic.get('src')
        print(f"Downloading image from {href}")
        if href is not None:
            img_resp = requests.get(href, headers=headers)
            tupian = img_resp.content
            tupian_name = href.split('/')[-1]
            print(f"Saving image as {tupian_name}")
            with open(os.path.join(save_path, tupian_name), mode='wb') as f:
                f.write(tupian)

    resp.close()

if __name__ == "__main__":
    url1 = "https://m.huiyi8.com/fengjing/zuimei/"
    download_images(url1, "C:\\Users\\lumic\\Desktop\\Python\\实验10 正则表达式与网络爬虫\\image2")