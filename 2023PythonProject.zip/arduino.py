import RPi.GPIO as GPIO
import Adafruit_DHT
import time
import cv2

# 设置 GPIO 模式为 BCM
GPIO.setmode(GPIO.BCM)

# 定义 DHT11 的数据引脚为 4 号
DHT_PIN = 4

# 定义光敏电阻的信号引脚为 17 号
LDR_PIN = 17

# 定义 HC-SR501 人体红外传感器信号引脚为 18 号
PIR_PIN = 18

# 定义灯光的信号引脚为 23 号
LED_PIN = 23

# 初始化 DHT11 传感器
dht_sensor = Adafruit_DHT.DHT11

# 设置光敏电阻的引脚为输入模式
GPIO.setup(LDR_PIN, GPIO.IN)

# 设置 HC-SR501 人体红外传感器信号引脚为输入模式
GPIO.setup(PIR_PIN, GPIO.IN)

# 设置灯光的信号引脚为输出模式
GPIO.setup(LED_PIN, GPIO.OUT)


# 定义一个函数，用于读取光敏电阻的状态
def read_ldr():
    # 读取引脚的电平，0 表示低电平，1 表示高电平
    value = GPIO.input(LDR_PIN)
    # 根据电平判断光线强度，低电平表示强光，高电平表示弱光
    if value == 0:
        return "Bright"
    else:
        return "Dark"


# 定义一个函数，用于检测人体是否存在
def detect_motion():
    # 读取 HC-SR501 人体红外传感器的状态
    if GPIO.input(PIR_PIN):
        return True
    else:
        return False


# 定义一个函数，用于控制灯光的开关状态
def control_light(status):
    if status:
        GPIO.output(LED_PIN, GPIO.HIGH)  # 打开灯光
    else:
        GPIO.output(LED_PIN, GPIO.LOW)  # 关闭灯光


# 在一个无限循环中读取传感器数据并打印在终端上
while True:
    # 读取 DHT11 传感器的温度和湿度数据
    humidity, temperature = Adafruit_DHT.read_retry(dht_sensor, DHT_PIN)

    # 读取光敏电阻的光线状态
    light = read_ldr()

    # 检测人体是否存在
    motion_detected = detect_motion()

    # 根据检测结果控制灯光的开关状态
    if motion_detected:
        control_light(True)  # 打开灯光
    else:
        control_light(False)  # 关闭灯光

    # 判断数据是否有效，如果有效则打印在终端上，否则提示错误信息
    if humidity is not None and temperature is not None:
        print(f"Temperature: {temperature} C, Humidity: {humidity} %, Light: {light}")
    else:
        print("Failed to read data from sensor")

    # 延时一秒
    time.sleep(1)